#include "../ck_rp.h"
#include "validate.h"
